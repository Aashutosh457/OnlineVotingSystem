

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Page</title>
        <link rel="stylesheet" href="./register.css">
    </head>

    <body>
        <section>
            <div class="form-box">
                <div class="form-value">
                    <form id="myform" action="" method="POST" onsubmit="validateForm(event)">
                    <h1> Padmashree International College</h1>
                        <h2>Register</h2>
                        <div class="inputbox">
                            <ion-icon name="mail-outline"></ion-icon>
                            <input type="text" id="name" name="name" value="" autocomplete="off" required>
                            <span id="nameError" class="error"></span>
                            <label for="name">Name</label>
                        </div>

            
                        <div class="inputbox">
                            <ion-icon name="mail-outline"></ion-icon>
                            <input type="email" id="email" name="email" value="" autocomplete="off" required>
                            <span id="emailError" class="error"></span>
                            <label for="email">E-mail</label>
                        </div>

                        <div class="inputbox">
                            <ion-icon name="call-outline"></ion-icon>
                            <input type="tel" id="phone" name="contact" value="" autocomplete="off" required>
                            <span id="phoneError" class="error"></span>
                            <label for="phone">Student Id</label>
                        </div>

                        <div class="inputbox">
                            <label for="gender" class="gender">Gender:</label>
                            <select id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="inputbox">
                            <ion-icon name="lock-closed-outline"></ion-icon>
                            <input type="password" id="password" name="password" value="" autocomplete="off" required>
                            <span id="passwordError" class="error"></span>
                            <label for="password">Password</label>
                        </div>

                        <div class="inputbox">
                            <ion-icon name="lock-closed-outline"></ion-icon>
                            <input type="password" id="cpassword" name="confirm_password" value="" autocomplete="off" required>
                            <span id="cpasswordError" class="error"></span>
                            <label for="cpassword">Confirm Password</label>
                        </div>

                        <button type="submit">Register</button>
                        <div class="register">
                            <p>Already Registered! <a href="./login.php">Login now</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <script src="./script.js"></script>
        <script src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js" type="module"></script>
        <script src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js" nomodule></script>
    </body>

</html>