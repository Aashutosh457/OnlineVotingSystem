<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="./login.css">
</head>

<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form id="myform" onsubmit="validateForm(event)">
                <h1> Padmashree International College</h1>
                    <h2>Login</h2>
                    <div class="inputbox">
                        <ion-icon name="mail-outline"></ion-icon>
                        <input type="email" id="email" autocomplete="off" required>
                        <span id="emailError" class="error"></span>
                        <label for="email">E-mail</label>
                    </div>

                    <div class="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" id="password" autocomplete="off" required>
                        <span id="passwordError" class="error"></span>
                        <label for="password">Password</label>
                    </div>

                    <div class="forget">
                        <label for="remember-checkbox">
                            <input type="checkbox" id="remember-checkbox">
                            Remember me
                            <a href="#">Forgot Password</a>
                        </label>
                    </div>

                    <button type="submit">Login</button>
                    <div class="register">
                        <p>Don't have an account? <a href="./register.php">Register now</a></p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script src="./script.js"></script>
    <script
        src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
        type="module"
    ></script>
    <script
        src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"
        nomodule
    ></script>
</body>
</html>
